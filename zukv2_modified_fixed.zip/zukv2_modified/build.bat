@echo off
echo   zukv2 CLI - Build Script
echo.

where dotnet >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: dotnet not found. Install .NET 8 SDK from:
    echo   https://dotnet.microsoft.com/download/dotnet/8.0
    pause
    exit /b 1
)

echo [*] Building  zukv2 CLI...
echo.

dotnet publish   zukv2.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -o bin\publish

if %errorlevel% neq 0 (
    echo.
    echo BUILD FAILED. Check errors above.
    pause
    exit /b 1
)

echo.
echo ============================================
echo  BUILD SUCCESS!
echo  Output: bin\publish\ zukv2.exe
echo ============================================
echo.
echo Usage:
echo    zukv2.exe input.lua output.lua
echo    zukv2.exe input.lua output.lua --no-mutate --no-superops
echo    zukv2.exe input.lua output.lua --encrypt-strings
echo    zukv2.exe input.lua --luac C:\path\to\luac5.1.exe
echo.
pause
