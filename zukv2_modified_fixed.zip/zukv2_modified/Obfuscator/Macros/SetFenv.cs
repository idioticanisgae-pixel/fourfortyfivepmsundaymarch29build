namespace zukv2.Obfuscator.Macros
{
	public class SetFenv
	{
		
	}
}