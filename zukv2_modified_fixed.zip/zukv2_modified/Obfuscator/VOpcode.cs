using zukv2.Bytecode_Library.IR;

namespace zukv2.Obfuscator
{
	public abstract class VOpcode
	{
		public int VIndex;
		
		public abstract bool IsInstruction(Instruction instruction);
		public abstract string GetObfuscated(ObfuscationContext context);
		public virtual void Mutate(Instruction instruction) { }
	}
}