using System;
using System.Collections.Generic;
using System.Linq;
using zukv2.Bytecode_Library.Bytecode;
using zukv2.Bytecode_Library.IR;
using zukv2.Extensions;

namespace zukv2.Obfuscator
{
	public enum ChunkStep
	{
		ParameterCount,
		StringTable,
		Instructions,
		Constants,
		Functions,
		LineInfo,
		StepCount
	}

	public enum InstructionStep1
	{
		Type,
		A,
		B,
		C,
		StepCount
	}

	public enum InstructionStep2
	{
		Op,
		Bx,
		D,
		StepCount
	}
	
	public class ObfuscationContext
	{
		public Chunk HeadChunk;
		public ChunkStep[] ChunkSteps;
		public InstructionStep1[] InstructionSteps1;
		public InstructionStep2[] InstructionSteps2;
		public int[] ConstantMapping;

		public Dictionary<Opcode, VOpcode> InstructionMapping = new Dictionary<Opcode, VOpcode>();

		public int PrimaryXorKey;
		public int IXorKey1;
		public int IXorKey2;

		// --- Randomized VM variable names ---
		public Dictionary<string, string> VmNames;

		// --- Randomized OP slot indices (1-6 shuffled) ---
		public int[] OpSlots; // [OP_ENUM, OP_A, OP_B, OP_BX, OP_C, OP_DATA]

		private static readonly string[] _chars = "lLIi".Select(c => c.ToString()).ToArray();
		private readonly HashSet<string> _usedNames = new HashSet<string>();

		private string RandName()
		{
			Random r = new Random(Guid.NewGuid().GetHashCode());
			string alpha = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
			while (true)
			{
				int len = r.Next(7, 12);
				char first = alpha[r.Next(alpha.Length)];
				string rest = new string(Enumerable.Range(0, len - 1)
					.Select(_ => "lLIi"[r.Next(4)]).ToArray());
				string name = first + rest;
				if (_usedNames.Add(name))
					return name;
			}
		}

		private static readonly string[] VmVarKeys = new[]
		{
			"Byte","Char","Sub","Concat","LDExp","GetFEnv","Setmetatable",
			"Select","Unpack","ToNumber",
			"BitXOR","gBit","gBits32","gBits8","gFloat","gSizet","gString","gInt",
			"Pos","ByteString",
			"Deserialize","Wrap","Loop",
			"Instr","Const","Proto","Params",
			"InstrPoint","Top","Vararg","Args","PCount","Lupvals","Stk",
			"Varargsz","Inst","Enum",
			"_R","PCall",
			"Chunk","Upvalues","Env","Idx",
			"IsNormal","Mantissa","Exponent","Sign",
			"Len","Str","FStr",
			"W","X","Y","Z","F",
			"Left","Right",
			"decompress","ra","rb","p","c","a","b",
		};

		public ObfuscationContext(Chunk chunk)
		{
			HeadChunk = chunk;
			ChunkSteps = Enumerable.Range(0, (int) ChunkStep.StepCount).Select(i => (ChunkStep) i).ToArray();
			ChunkSteps.Shuffle();
			
			InstructionSteps1 = Enumerable.Range(0, (int) InstructionStep1.StepCount).Select(i => (InstructionStep1) i).ToArray();
			InstructionSteps1.Shuffle();
			
			InstructionSteps2 = Enumerable.Range(0, (int) InstructionStep2.StepCount).Select(i => (InstructionStep2) i).ToArray();
			InstructionSteps2.Shuffle();
			
			ConstantMapping = Enumerable.Range(0, 4).ToArray();
			ConstantMapping.Shuffle();

			Random rand = new Random();
			
			PrimaryXorKey = rand.Next(0, 256);
			IXorKey1 = rand.Next(0, 256);
			IXorKey2 = rand.Next(0, 256);

			// Build randomized name table
			VmNames = new Dictionary<string, string>();
			foreach (string key in VmVarKeys)
				VmNames[key] = RandName();

			// Randomize OP slot indices: shuffle 1..6
			OpSlots = Enumerable.Range(1, 6).ToArray();
			OpSlots.Shuffle();
			// OpSlots[0]=OP_ENUM, [1]=OP_A, [2]=OP_B, [3]=OP_BX, [4]=OP_C, [5]=OP_DATA
		}

		/// <summary>Apply all VmNames substitutions to a VM string template.</summary>
		public string ApplyNames(string template)
		{
			// Replace longest keys first to avoid partial matches
			foreach (var kv in VmNames.OrderByDescending(x => x.Key.Length))
				template = template.Replace(kv.Key, kv.Value);
			return template;
		}
	}
}
