using zukv2.Bytecode_Library.IR;

namespace zukv2.Obfuscator.Control_Flow.Types
{
    public static class NumberMutate
    {
        public static void DoInstructions(Chunk chunk)
        {
            
        }
    }
}