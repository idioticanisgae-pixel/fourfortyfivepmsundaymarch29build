local Step = require("ZukaTech.step")
local Ast = require("ZukaTech.ast")
local Scope = require("ZukaTech.scope")
local RandomStrings = require("ZukaTech.randomStrings")
local Parser = require("ZukaTech.parser")
local Enums = require("ZukaTech.enums")
local logger = require("logger")
local visitast = require("ZukaTech.visitast")
local util = require("ZukaTech.util")
local AstKind = Ast.AstKind

local EncryptStrings = Step:extend()
EncryptStrings.Description = "This Step will encrypt strings within your Program."
EncryptStrings.Name = "Encrypt Strings"
EncryptStrings.SettingsDescriptor = {}

function EncryptStrings:init(settings) end

-- ─── Compile-time cipher ──────────────────────────────────────────────────────
-- Runs inside the obfuscator only. Uses xoshiro128** PRNG + two-pass cipher.
-- Raw keys are split into sub-values; no true key appears in the generated code.
function EncryptStrings:CreateEncrypionService()
    local usedSeeds = {}
    local M = 2^32
    local floor = math.floor

    -- bxor32: pure Lua 5.1 bitwise XOR (defined first — everything depends on it)
    local function bxor32(a, b)
        local r, m = 0, 1
        a, b = a % M, b % M
        while a > 0 or b > 0 do
            local ra = a % 2
            local rb = b % 2
            if ra ~= rb then r = r + m end
            a = floor(a / 2)
            b = floor(b / 2)
            m = m * 2
        end
        return r
    end

    -- rotl32: bit-rotate left within 32 bits
    local function rotl32(x, k)
        x = x % M
        return ((x * (2^k)) % M) + floor(x / (2^(32 - k)))
    end

    -- splitmix32 hash for seeding xoshiro
    local function splitmix(z)
        z = (bxor32(z, floor(z / 65536)) * 0x85ebca6b) % M
        return bxor32(z, floor(z / 8192))
    end

    -- xoshiro128** state
    local s0, s1, s2, s3 = 0, 0, 0, 0

    local function xoshiro_next()
        local result = (rotl32(s1 * 5, 7) * 9) % M
        local t = (s1 * (2^17)) % M
        s2 = bxor32(s2, s0)
        s3 = bxor32(s3, s1)
        s1 = bxor32(s1, s2)
        s0 = bxor32(s0, s3)
        s2 = bxor32(s2, t)
        s3 = rotl32(s3, 11)
        return result
    end

    local function set_seed(seed)
        s0 = splitmix((seed + 0x9e3779b9) % M)
        s1 = splitmix((seed + 0x6c62272e) % M)
        s2 = (s0 * 1664525 + 1013904223) % M
        s3 = (s1 * 22695477 + 1) % M
        for _ = 1, 8 do xoshiro_next() end
    end

    local function gen_seed()
        local seed
        repeat seed = math.random(0, 2147483647)
        until not usedSeeds[seed]
        usedSeeds[seed] = true
        return seed
    end

    local prev_bytes = {}
    local function get_next_byte()
        if #prev_bytes == 0 then
            local r = xoshiro_next()
            prev_bytes = {
                r % 256,
                floor(r / 256) % 256,
                floor(r / 65536) % 256,
                floor(r / 16777216) % 256,
            }
        end
        return table.remove(prev_bytes)
    end

    -- Key splitting: raw_key = A XOR B XOR C
    -- Only A, B, C appear in the generated decryptor; raw_key never does.
    local raw_key = math.random(1, 255)
    local key_A   = math.random(1, 255)
    local key_B   = math.random(1, 255)
    local key_C   = bxor32(bxor32(raw_key, key_A), key_B)

    -- Round constant, also split: raw_rc = rc_A XOR rc_B
    local raw_rc = math.random(1, 127)
    local rc_A   = math.random(1, 255)
    local rc_B   = bxor32(raw_rc, rc_A)

    -- Encrypt one string at compile-time
    local function encrypt(str)
        local seed = gen_seed()
        set_seed(seed)
        prev_bytes = {}
        local out  = {}
        local roll = raw_key
        for i = 1, #str do
            local b  = string.byte(str, i)
            local kb = get_next_byte()
            local c  = bxor32(b, bxor32(kb, roll))
            c = (c + raw_rc) % 256
            out[i] = string.char(c)
            roll = (roll + b + raw_rc) % 256
        end
        return table.concat(out), seed
    end

    -- ── Runtime decryptor generator ───────────────────────────────────────────
    -- %% inside the returned strings are literal % (escaped for string.format).
    local function genCode()
        local shape  = math.random(1, 3)
        local sA     = tostring(key_A)
        local sB     = tostring(key_B)
        local sC     = tostring(key_C)
        local rA     = tostring(rc_A)
        local rB     = tostring(rc_B)
        local warmup = tostring(math.random(6, 12))

        if shape == 1 then return ([[
do
    local _f=math.floor local _rm=table.remove
    local _ch=string.char local _by=string.byte local _ln=string.len
    local _M=2^32
    local function _bx(a,b)
        local r,m=0,1 a,b=a%%_M,b%%_M
        while a>0 or b>0 do
            local ra=a%%2 local rb=b%%2
            if ra~=rb then r=r+m end
            a=_f(a/2) b=_f(b/2) m=m*2
        end
        return r
    end
    local _KA=_bx(_bx(%s,%s),%s)
    local _RC=_bx(%s,%s)
    local _s0,_s1,_s2,_s3=0,0,0,0
    local _pb={}
    local function _rl(x,k) x=x%%_M return (_f(x*(2^k))%%_M)+_f(x/(2^(32-k))) end
    local function _nx()
        local res=(_rl(_s1*5,7)*9)%%_M
        local t=(_s1*(2^17))%%_M
        _s2=_bx(_s2,_s0) _s3=_bx(_s3,_s1)
        _s1=_bx(_s1,_s2) _s0=_bx(_s0,_s3)
        _s2=_bx(_s2,t) _s3=_rl(_s3,11)
        return res
    end
    local function _sm(z) z=(_bx(z,_f(z/65536))*0x85ebca6b)%%_M return _bx(z,_f(z/8192)) end
    local function _ss(seed)
        _s0=_sm((seed+0x9e3779b9)%%_M) _s1=_sm((seed+0x6c62272e)%%_M)
        _s2=(_s0*1664525+1013904223)%%_M _s3=(_s1*22695477+1)%%_M
        for _i=1,%s do _nx() end
    end
    local function _nb()
        if #_pb==0 then
            local v=_nx()
            _pb={v%%256,_f(v/256)%%256,_f(v/65536)%%256,_f(v/16777216)%%256}
        end
        return _rm(_pb)
    end
    local _cm={}
    do
        local _t={} for i=1,256 do _t[i]=i end
        _ss(0xdeadbeef)
        for i=256,2,-1 do local j=(_nx()%%i)+1 _t[i],_t[j]=_t[j],_t[i] end
        for i=1,256 do _cm[i]=_ch(_t[i]-1) end
    end
    local _cache={}
    local function _dc(str,seed)
        if not _cache[seed] then
            _pb={} _ss(seed)
            local n=_ln(str) local roll=_KA local p={}
            for i=1,n do
                local enc=_by(str,i) local kb=_nb()
                local tmp=(enc-_RC+256)%%256
                local dec=_bx(tmp,_bx(kb,roll))%%256
                p[i]=_cm[dec+1]
                roll=(roll+dec+_RC)%%256
            end
            _cache[seed]=table.concat(p)
        end
        return seed
    end
    STRINGS=setmetatable({},{
        __index=function(_,k) return _cache[k] end,
        __newindex=function() error("read-only",2) end,
        __metatable=false,
    })
    function DECRYPT(s,k) return _dc(s,k) end
end]]):format(sA,sB,sC,rA,rB,warmup)

        elseif shape == 2 then return ([[
do
    local F=math.floor local RM=table.remove
    local CH=string.char local BY=string.byte local LN=string.len
    local MOD=2^32
    local function XR(a,b)
        local r,m=0,1 a,b=a%%MOD,b%%MOD
        while a>0 or b>0 do
            local u=a%%2 local v=b%%2
            if u~=v then r=r+m end
            a=F(a/2) b=F(b/2) m=m*2
        end
        return r
    end
    local KEY=XR(XR(%s,%s),%s)
    local RCN=XR(%s,%s)
    local S0,S1,S2,S3=0,0,0,0
    local PB={}
    local function RL(x,k) x=x%%MOD return (F(x*(2^k))%%MOD)+F(x/(2^(32-k))) end
    local function NX()
        local res=(RL(S1*5,7)*9)%%MOD
        local t=(S1*(2^17))%%MOD
        S2=XR(S2,S0) S3=XR(S3,S1) S1=XR(S1,S2) S0=XR(S0,S3)
        S2=XR(S2,t) S3=RL(S3,11) return res
    end
    local function SM(z) z=(XR(z,F(z/65536))*0x85ebca6b)%%MOD return XR(z,F(z/8192)) end
    local function SS(seed)
        S0=SM((seed+0x9e3779b9)%%MOD) S1=SM((seed+0x6c62272e)%%MOD)
        S2=(S0*1664525+1013904223)%%MOD S3=(S1*22695477+1)%%MOD
        for _i=1,%s do NX() end
    end
    local function NB()
        if #PB==0 then
            local v=NX()
            PB={v%%256,F(v/256)%%256,F(v/65536)%%256,F(v/16777216)%%256}
        end
        return RM(PB)
    end
    local CM={}
    do
        local T={} for i=1,256 do T[i]=i end
        SS(0xdeadbeef)
        for i=256,2,-1 do local j=(NX()%%i)+1 T[i],T[j]=T[j],T[i] end
        for i=1,256 do CM[i]=CH(T[i]-1) end
    end
    local CACHE={}
    local function DC(str,seed)
        if not CACHE[seed] then
            PB={} SS(seed)
            local n=LN(str) local roll=KEY local p={}
            for i=1,n do
                local enc=BY(str,i) local kb=NB()
                local tmp=(enc-RCN+256)%%256
                local dec=XR(tmp,XR(kb,roll))%%256
                p[i]=CM[dec+1]
                roll=(roll+dec+RCN)%%256
            end
            CACHE[seed]=table.concat(p)
        end
        return seed
    end
    STRINGS=setmetatable({},{
        __index=function(_,k) return CACHE[k] end,
        __newindex=function() error("read-only",2) end,
        __metatable=false,
    })
    function DECRYPT(s,k) return DC(s,k) end
end]]):format(sA,sB,sC,rA,rB,warmup)

        else return ([[
do
    local _={}
    local ff=math.floor local rm=table.remove
    local cc=string.char local bb=string.byte local ll=string.len
    local MM=2^32
    local function xx(a,b)
        local r,m=0,1 a,b=a%%MM,b%%MM
        while a>0 or b>0 do
            local p=a%%2 local q=b%%2
            if p~=q then r=r+m end
            a=ff(a/2) b=ff(b/2) m=m*2
        end
        return r
    end
    _.k=xx(xx(%s,%s),%s) _.rc=xx(%s,%s)
    _.s0,_.s1,_.s2,_.s3=0,0,0,0 _.pb={}
    local function rl(x,k) x=x%%MM return (ff(x*(2^k))%%MM)+ff(x/(2^(32-k))) end
    local function nx()
        local res=(rl(_.s1*5,7)*9)%%MM
        local t=(_.s1*(2^17))%%MM
        _.s2=xx(_.s2,_.s0) _.s3=xx(_.s3,_.s1)
        _.s1=xx(_.s1,_.s2) _.s0=xx(_.s0,_.s3)
        _.s2=xx(_.s2,t) _.s3=rl(_.s3,11) return res
    end
    local function sm(z) z=(xx(z,ff(z/65536))*0x85ebca6b)%%MM return xx(z,ff(z/8192)) end
    local function ss(seed)
        _.s0=sm((seed+0x9e3779b9)%%MM) _.s1=sm((seed+0x6c62272e)%%MM)
        _.s2=(_.s0*1664525+1013904223)%%MM _.s3=(_.s1*22695477+1)%%MM
        for _i=1,%s do nx() end
    end
    local function nb()
        if #_.pb==0 then
            local v=nx()
            _.pb={v%%256,ff(v/256)%%256,ff(v/65536)%%256,ff(v/16777216)%%256}
        end
        return rm(_.pb)
    end
    _.cm={}
    do
        local t={} for i=1,256 do t[i]=i end
        ss(0xdeadbeef)
        for i=256,2,-1 do local j=(nx()%%i)+1 t[i],t[j]=t[j],t[i] end
        for i=1,256 do _.cm[i]=cc(t[i]-1) end
    end
    _.cache={}
    local function dc(str,seed)
        if not _.cache[seed] then
            _.pb={} ss(seed)
            local n=ll(str) local roll=_.k local p={}
            for i=1,n do
                local enc=bb(str,i) local kb=nb()
                local tmp=(enc-_.rc+256)%%256
                local dec=xx(tmp,xx(kb,roll))%%256
                p[i]=_.cm[dec+1]
                roll=(roll+dec+_.rc)%%256
            end
            _.cache[seed]=table.concat(p)
        end
        return seed
    end
    STRINGS=setmetatable({},{
        __index=function(tbl,k) return _.cache[k] end,
        __newindex=function() error("read-only",2) end,
        __metatable=false,
    })
    function DECRYPT(s,k) return dc(s,k) end
end]]):format(sA,sB,sC,rA,rB,warmup)
        end
    end

    return {
        encrypt = encrypt,
        genCode = genCode,
    }
end

-- ─── AST application pass ────────────────────────────────────────────────────
function EncryptStrings:apply(ast, pipeline)
    local Encryptor = self:CreateEncrypionService()
    local code   = Encryptor.genCode()
    local newAst = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 }):parse(code)
    local doStat = newAst.body.statements[1]

    local scope      = ast.body.scope
    local decryptVar = scope:addVariable()
    local stringsVar = scope:addVariable()

    doStat.body.scope:setParent(ast.body.scope)

    visitast(newAst, nil, function(node, data)
        if node.kind == AstKind.FunctionDeclaration then
            if node.scope:getVariableName(node.id) == "DECRYPT" then
                data.scope:removeReferenceToHigherScope(node.scope, node.id)
                data.scope:addReferenceToHigherScope(scope, decryptVar)
                node.scope = scope
                node.id    = decryptVar
            end
        end
        if node.kind == AstKind.AssignmentVariable or node.kind == AstKind.VariableExpression then
            if node.scope:getVariableName(node.id) == "STRINGS" then
                data.scope:removeReferenceToHigherScope(node.scope, node.id)
                data.scope:addReferenceToHigherScope(scope, stringsVar)
                node.scope = scope
                node.id    = stringsVar
            end
        end
    end)

    visitast(ast, nil, function(node, data)
        if node.kind == AstKind.StringExpression then
            data.scope:addReferenceToHigherScope(scope, stringsVar)
            data.scope:addReferenceToHigherScope(scope, decryptVar)
            local encrypted, seed = Encryptor.encrypt(node.value)
            return Ast.IndexExpression(
                Ast.VariableExpression(scope, stringsVar),
                Ast.FunctionCallExpression(Ast.VariableExpression(scope, decryptVar), {
                    Ast.StringExpression(encrypted),
                    Ast.NumberExpression(seed),
                })
            )
        end
    end)

    local insertPos = 1
    if ast.body.statements[1] and ast.body.statements[1].kind == AstKind.DoStatement then
        insertPos = 2
    end

    table.insert(ast.body.statements, insertPos, doStat)
    table.insert(ast.body.statements, insertPos,
        Ast.LocalVariableDeclaration(scope, util.shuffle{ decryptVar, stringsVar }, {}))

    return ast
end

return EncryptStrings
