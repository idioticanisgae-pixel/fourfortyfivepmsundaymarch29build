-- steps/VariableRenamer.lua
-- ZukaTech Obfuscation Step: Variable Renamer
--
-- Runs AFTER the AST is unparsed to source (post-unparse pass).
-- Renames local variables and functions to random alphabetic identifiers,
-- and aliases built-in Lua / Roblox globals at the top of the output.
--
-- SettingsDescriptor:
--   MinLength  (number, default 8)  — minimum length of generated names
--   MaxLength  (number, default 12) — maximum length of generated names
--
-- Add to your preset Steps table:
--   { Name = "VariableRenamer", Settings = { MinLength = 8, MaxLength = 14 } }

local Step   = require("ZukaTech.step")
local logger = require("logger")

-- ── core logic (ported from variable_renamer.lua) ────────────────────────────

local varenc_names = {}

local lua_functions = {
    "assert", "collectgarbage", "dofile", "loadfile", "loadstring",
    "ipairs", "pairs", "tonumber", "tostring", "type", "print",
    "_G", "_VERSION", "write", "sort",
    "math.abs", "math.acos", "math.asin", "math.atan", "math.atan2",
    "math.ceil", "math.cos", "math.cosh", "math.deg", "math.exp",
    "math.floor", "math.fmod", "math.frexp", "math.ldexp", "math.log",
    "math.log10", "math.max", "math.min", "math.modf", "math.pi",
    "math.pow", "math.rad", "math.random", "math.randomseed", "math.sin",
    "math.sinh", "math.sqrt", "math.tan", "math.tanh",
    "string.byte", "string.char", "string.dump", "string.find",
    "string.format", "string.gmatch", "string.gsub", "string.len",
    "string.lower", "string.match", "string.rep", "string.reverse",
    "string.sub", "string.upper",
    "table.concat", "table.insert", "table.remove", "table.sort",
    "table.pack", "table.unpack", "game:GetService",
}

local reserved_words = {
    ["if"]=true, ["then"]=true, ["else"]=true, ["elseif"]=true, ["end"]=true,
    ["for"]=true, ["while"]=true, ["do"]=true, ["repeat"]=true, ["until"]=true,
    ["function"]=true, ["local"]=true, ["return"]=true, ["break"]=true, ["continue"]=true,
    ["and"]=true, ["or"]=true, ["not"]=true, ["in"]=true, ["nil"]=true,
    ["true"]=true, ["false"]=true,
}

local DEFAULT_MIN = 8
local DEFAULT_MAX = 12

local function generateRandomName(name_min, name_max)
    local len     = math.random(name_min, name_max)
    local charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    local clen    = #charset
    local name    = {}
    for _ = 1, len do
        local i = math.random(1, clen)
        name[#name + 1] = charset:sub(i, i)
    end
    return table.concat(name)
end

local function replaceUnquoted(input, target, replacement)
    local placeholder = "\xFE\xFF\xFE_ZUKA_PH_\xFE\xFF\xFE"
    local protected = input:gsub('(["\'])(.-)%1', function(q, content)
        content = content:gsub('\\"', '\1'):gsub("\\'", '\2')
        content = content:gsub(target, placeholder)
        content = content:gsub('\1', '\\"'):gsub('\2', "\\'")
        return q .. content .. q
    end)
    local result = protected:gsub('(%f[%w_])' .. target .. '(%f[^%w_])', replacement)
    result = result:gsub(placeholder, target)
    return result
end

local function obfuscateLocalVariables(code, name_min, name_max)
    local var_map = {}
    local obfuscated = code
    for local_vars in code:gmatch("local%s+([%w_,%s]+)%s*=%s*") do
        for var in local_vars:gmatch("[%w_]+") do
            if  #var > 1
            and not varenc_names[var]
            and not reserved_words[var]
            and not var:match("^__")
            and not var:match("^_ZukaTech")
            and not var_map[var]
            then
                var_map[var] = generateRandomName(name_min, name_max)
            end
        end
    end
    for orig, renamed in pairs(var_map) do
        obfuscated = replaceUnquoted(obfuscated, orig, renamed)
    end
    return obfuscated
end

local function obfuscateFunctions(code, name_min, name_max)
    local func_map = {}
    local arg_map  = {}
    local obfuscated = code
    for func_name, args in code:gmatch("function%s+([%w_]+)%s*%(([%w_,%s]*)%)") do
        if  not reserved_words[func_name]
        and not func_map[func_name]
        and not func_name:match("^__")
        and not func_name:match("^_ZukaTech")
        then
            func_map[func_name] = generateRandomName(name_min, name_max)
        end
        for arg in args:gmatch("[%w_]+") do
            if not reserved_words[arg] and not arg_map[arg] then
                arg_map[arg] = generateRandomName(name_min, name_max)
            end
        end
    end
    obfuscated = obfuscated:gsub("function%s+([%w_]+)", function(fn)
        return "function " .. (func_map[fn] or fn)
    end)
    for orig, renamed in pairs(func_map) do
        obfuscated = obfuscated:gsub(orig .. "%(", renamed .. "(")
    end
    for orig, renamed in pairs(arg_map) do
        obfuscated = replaceUnquoted(obfuscated, orig, renamed)
    end
    return obfuscated
end

local function processSource(code, name_min, name_max)
    -- reset per-run alias table
    varenc_names = {}

    local renamed_vars    = {}
    local assignment_lines = {}

    local out = obfuscateLocalVariables(code, name_min, name_max)
    out = obfuscateFunctions(out, name_min, name_max)

    for _, fn in ipairs(lua_functions) do
        if code:find(fn, 1, true) then
            if not varenc_names[fn] then
                local alias = generateRandomName(name_min, name_max)
                varenc_names[fn] = alias
                renamed_vars[#renamed_vars + 1]     = alias
                assignment_lines[#assignment_lines + 1] = alias .. " = " .. fn .. ";"
            end
            out = out:gsub(fn .. "%(", varenc_names[fn] .. "(")
        end
    end

    local decl    = #renamed_vars > 0 and ("local " .. table.concat(renamed_vars, ", ")) or ""
    local assigns = #assignment_lines > 0 and ("\n" .. table.concat(assignment_lines, " ")) or ""
    return decl .. assigns .. "\n" .. out
end

-- ── Step interface ────────────────────────────────────────────────────────────

local VariableRenamer = Step:extend()
VariableRenamer.Name        = "VariableRenamer"
VariableRenamer.Description = "Post-unparse pass: renames local variables/functions and aliases Lua globals to random identifiers."

VariableRenamer.SettingsDescriptor = {
    MinLength = {
        name        = "MinLength",
        description = "Minimum length of generated identifier names",
        type        = "number",
        default     = DEFAULT_MIN,
        min         = 2,
        max         = 64,
    },
    MaxLength = {
        name        = "MaxLength",
        description = "Maximum length of generated identifier names",
        type        = "number",
        default     = DEFAULT_MAX,
        min         = 2,
        max         = 64,
    },
}

function VariableRenamer:init(settings)
    self.MinLength = self.MinLength or DEFAULT_MIN
    self.MaxLength = self.MaxLength or DEFAULT_MAX
end

-- Register as a post-unparse pass (runs after AST steps + unparser,
-- same timing as BlobCompress / ZukaZalgo).
function VariableRenamer:apply(ast, pipeline)
    if pipeline._varRenamerStep then
        logger:warn("[VariableRenamer] Multiple VariableRenamer steps detected — last one wins.")
    end
    pipeline._varRenamerStep = self
    return ast  -- AST is untouched; real work is in :process()
end

-- Called by the pipeline post-unparse hook (see pipeline.lua patch below).
function VariableRenamer:process(source)
    logger:info("[VariableRenamer] Renaming variables post-unparse …")
    local result = processSource(source, self.MinLength, self.MaxLength)
    logger:info("[VariableRenamer] Done.")
    return result
end

return VariableRenamer