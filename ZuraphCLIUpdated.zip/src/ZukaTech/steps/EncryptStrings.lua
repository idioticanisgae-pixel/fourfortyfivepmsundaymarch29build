-- Obfuscation Step: Encrypt Strings
local Step = require("ZukaTech.step")
local Ast = require("ZukaTech.ast")
local Scope = require("ZukaTech.scope")
local RandomStrings = require("ZukaTech.randomStrings")
local Parser = require("ZukaTech.parser")
local Enums = require("ZukaTech.enums")
local logger = require("logger")
local visitast = require("ZukaTech.visitast");
local util     = require("ZukaTech.util")
local AstKind = Ast.AstKind;

local EncryptStrings = Step:extend()
EncryptStrings.Description = "This Step will encrypt strings within your Program."
EncryptStrings.Name = "Encrypt Strings"

EncryptStrings.SettingsDescriptor = {}

function EncryptStrings:init(settings) end


function EncryptStrings:CreateEncrypionService()
	local usedSeeds = {};

	-- Keys with different bit widths than original to change fingerprint
	local key_a = math.random(1, 255)        -- xor base key
	local key_b = math.random(0, 511)        -- 9-bit mix key
	local key_c = math.random(0, 8191)       -- 13-bit lcg seed component
	local key_d = math.random(0, 65535)      -- 16-bit additive constant

	local floor = math.floor

	-- Lua 5.1 compatible XOR (no ~ operator)
	local function bxor(a, b)
		local r, m = 0, 1
		while a > 0 or b > 0 do
			local ra = a % 2
			local rb = b % 2
			if ra ~= rb then r = r + m end
			a = floor(a / 2)
			b = floor(b / 2)
			m = m * 2
		end
		return r
	end

	-- Simple LCG-based state with different multiplier/modulus than original
	-- Using a different prime multiplier: 1664525 (Numerical Recipes)
	local lcg_mul = 1664525
	local lcg_add = key_d * 2 + 1
	local lcg_mod = 2^32

	local state_lcg = 0
	local rot_state = 1

	local prev_bytes = {}

	local function set_seed(seed)
		state_lcg = seed % lcg_mod
		rot_state  = (seed % 251) + 1  -- keep in 1..251
		prev_bytes = {}
	end

	local function gen_seed()
		local seed
		repeat
			seed = math.random(0, 2147483647)
		until not usedSeeds[seed]
		usedSeeds[seed] = true
		return seed
	end

	-- Different PRNG output: combines LCG with a small rotation counter
	local function next_rand_32()
		state_lcg = (state_lcg * lcg_mul + lcg_add) % lcg_mod
		-- mix in rot_state so consecutive outputs differ more
		rot_state = (rot_state * 37 + 7) % 251 + 1
		local mixed = (state_lcg + rot_state * 65537) % lcg_mod
		return floor(mixed)
	end

	local function get_next_byte()
		if #prev_bytes == 0 then
			local r   = next_rand_32()
			local b1  = r % 256
			local b2  = floor(r / 256) % 256
			local b3  = floor(r / 65536) % 256
			local b4  = floor(r / 16777216) % 256
			prev_bytes = { b1, b2, b3, b4 }
		end
		return table.remove(prev_bytes)
	end

	-- Encrypt: XOR with (prng_byte XOR rolling_key) instead of subtract
	local function encrypt(str)
		local seed = gen_seed()
		set_seed(seed)
		local len = #str
		local out = {}
		local roll = key_a   -- rolling xor key, starts at key_a
		for i = 1, len do
			local b = string.byte(str, i)
			local kb = get_next_byte()
			-- XOR the byte with combined key, then roll
			out[i] = string.char(bxor(b, bxor(kb, roll)) % 256)
			roll = (roll + b + 13) % 256
		end
		return table.concat(out), seed
	end

	local function genCode()
		-- IMPROVEMENT 3 — Rotate decrypt shape per compile.
		-- Three structurally distinct decrypt patterns so the
		-- STRINGS[DECRYPT(blob, seed)] fingerprint is never consistent.
		local shape = math.random(1, 3)

		if shape == 1 then
		-- ── Shape 1: original direct-function form ────────────────────────────
		local code = [[
do
	local floor = math.floor
	local random = math.random
	local remove = table.remove
	local char   = string.char
	local byte   = string.byte
	local len    = string.len

	local lcg_mul  = ]] .. tostring(lcg_mul) .. [[

	local lcg_add  = ]] .. tostring(lcg_add) .. [[

	local lcg_mod  = 2^32
	local key_a    = ]] .. tostring(key_a) .. [[

	local floor    = math.floor

	local function bxor(a, b)
		local r, m = 0, 1
		while a > 0 or b > 0 do
			local ra = a % 2
			local rb = b % 2
			if ra ~= rb then r = r + m end
			a = floor(a / 2)
			b = floor(b / 2)
			m = m * 2
		end
		return r
	end
	local state_lcg = 0
	local rot_state  = 1
	local prev_bytes = {}

	local charmap = {}
	local nums = {}
	for i = 1, 256 do nums[i] = i end
	repeat
		local idx = random(1, #nums)
		local n   = remove(nums, idx)
		charmap[n] = char(n - 1)
	until #nums == 0

	local function next_rand_32()
		state_lcg = (state_lcg * lcg_mul + lcg_add) % lcg_mod
		rot_state  = (rot_state * 37 + 7) % 251 + 1
		return floor((state_lcg + rot_state * 65537) % lcg_mod)
	end

	local function get_next_byte()
		if #prev_bytes == 0 then
			local r  = next_rand_32()
			local b1 = r % 256
			local b2 = floor(r / 256) % 256
			local b3 = floor(r / 65536) % 256
			local b4 = floor(r / 16777216) % 256
			prev_bytes = { b1, b2, b3, b4 }
		end
		return remove(prev_bytes)
	end

	local realStrings = {}
	STRINGS = setmetatable({}, {
		__index = realStrings,
		__metatable = nil,
	})

	function DECRYPT(str, seed)
		local cache = realStrings
		if not cache[seed] then
			prev_bytes  = {}
			state_lcg   = seed % lcg_mod
			rot_state   = (seed % 251) + 1
			local slen  = len(str)
			local roll  = key_a
			local parts = {}
			local cm    = charmap
			for i = 1, slen do
				local enc = byte(str, i)
				local kb  = get_next_byte()
				local dec = bxor(enc, bxor(kb, roll)) % 256
				parts[i]  = cm[dec + 1]
				roll       = (roll + dec + 13) % 256
			end
			cache[seed] = table.concat(parts)
		end
		return seed
	end
end]]
		return code

		elseif shape == 2 then
		-- ── Shape 2: closure factory — DECRYPT is a closure returned by a
		--   builder function, routed through a metatable __index on STRINGS.
		--   No top-level DECRYPT name visible; the method lives inside the meta.
		local code = [[
do
	local _f = math.floor
	local _r = math.random
	local _rm = table.remove
	local _ch = string.char
	local _by = string.byte
	local _ln = string.len

	local _lm  = ]] .. tostring(lcg_mul) .. [[

	local _la  = ]] .. tostring(lcg_add) .. [[

	local _lmod = 2^32
	local _ka   = ]] .. tostring(key_a) .. [[

	local function _bx(a,b)
		local r,m=0,1
		while a>0 or b>0 do
			local ra=a%2 local rb=b%2
			if ra~=rb then r=r+m end
			a=_f(a/2) b=_f(b/2) m=m*2
		end
		return r
	end

	local _sl,_rs,_pb=0,1,{}
	local _cm={}
	local _ns={}
	for i=1,256 do _ns[i]=i end
	repeat
		local idx=_r(1,#_ns)
		local n=_rm(_ns,idx)
		_cm[n]=_ch(n-1)
	until #_ns==0

	local function _nr()
		_sl=(_sl*_lm+_la)%_lmod
		_rs=(_rs*37+7)%251+1
		return _f((_sl+_rs*65537)%_lmod)
	end
	local function _nb()
		if #_pb==0 then
			local rv=_nr()
			_pb={rv%256,_f(rv/256)%256,_f(rv/65536)%256,_f(rv/16777216)%256}
		end
		return _rm(_pb)
	end

	local _cache={}
	local function _dec(str,seed)
		if not _cache[seed] then
			_pb={} _sl=seed%_lmod _rs=(seed%251)+1
			local slen=_ln(str) local roll=_ka local parts={}
			for i=1,slen do
				local enc=_by(str,i) local kb=_nb()
				local dec=_bx(enc,_bx(kb,roll))%256
				parts[i]=_cm[dec+1]
				roll=(roll+dec+13)%256
			end
			_cache[seed]=table.concat(parts)
		end
		return seed
	end

	STRINGS = setmetatable({}, {
		__index = function(_, k) return _cache[k] end,
		__metatable = nil,
	})
	function DECRYPT(s,k) return _dec(s,k) end
end]]
		return code

		else
		-- ── Shape 3: method on a module table, STRINGS uses __newindex to
		--   populate itself lazily.  DECRYPT is stored as a field, not a global.
		local code = [[
do
	local _M={}
	local _F=math.floor
	local _R=math.random
	local _RM=table.remove
	local _C=string.char
	local _B=string.byte
	local _L=string.len

	local _MUL=]] .. tostring(lcg_mul) .. [[

	local _ADD=]] .. tostring(lcg_add) .. [[

	local _MOD=2^32
	local _KA=]] .. tostring(key_a) .. [[

	local function _XR(a,b)
		local r,m=0,1
		while a>0 or b>0 do
			local u=a%2 local v=b%2
			if u~=v then r=r+m end
			a=_F(a/2) b=_F(b/2) m=m*2
		end
		return r
	end

	local _SL,_RT,_PB=0,1,{}
	local _MAP={}
	local _TMP={}
	for i=1,256 do _TMP[i]=i end
	repeat
		local i=_R(1,#_TMP) local n=_RM(_TMP,i) _MAP[n]=_C(n-1)
	until #_TMP==0

	local function _NX()
		_SL=(_SL*_MUL+_ADD)%_MOD
		_RT=(_RT*37+7)%251+1
		return _F((_SL+_RT*65537)%_MOD)
	end
	local function _NB()
		if #_PB==0 then
			local v=_NX()
			_PB={v%256,_F(v/256)%256,_F(v/65536)%256,_F(v/16777216)%256}
		end
		return _RM(_PB)
	end

	_M._cache={}
	_M.dec=function(str,seed)
		if not _M._cache[seed] then
			_PB={} _SL=seed%_MOD _RT=(seed%251)+1
			local n=_L(str) local roll=_KA local p={}
			for i=1,n do
				local e=_B(str,i) local k=_NB()
				local d=_XR(e,_XR(k,roll))%256
				p[i]=_MAP[d+1] roll=(roll+d+13)%256
			end
			_M._cache[seed]=table.concat(p)
		end
		return seed
	end

	STRINGS=setmetatable({},{
		__index=function(_,k) return _M._cache[k] end,
		__metatable=nil,
	})
	function DECRYPT(s,k) return _M.dec(s,k) end
end]]
		return code
		end  -- shape
	end

	return {
		encrypt  = encrypt,
		genCode  = genCode,
		-- expose keys so nothing breaks if other steps inspect them
		key_a    = key_a,
		lcg_mul  = lcg_mul,
		lcg_add  = lcg_add,
	}
end

function EncryptStrings:apply(ast, pipeline)
	local Encryptor = self:CreateEncrypionService()

	local code   = Encryptor.genCode()
	local newAst = Parser:new({ LuaVersion = Enums.LuaVersion.Lua51 }):parse(code)
	local doStat = newAst.body.statements[1]

	local scope      = ast.body.scope
	local decryptVar = scope:addVariable()
	local stringsVar = scope:addVariable()

	doStat.body.scope:setParent(ast.body.scope)

	visitast(newAst, nil, function(node, data)
		if node.kind == AstKind.FunctionDeclaration then
			if node.scope:getVariableName(node.id) == "DECRYPT" then
				data.scope:removeReferenceToHigherScope(node.scope, node.id)
				data.scope:addReferenceToHigherScope(scope, decryptVar)
				node.scope = scope
				node.id    = decryptVar
			end
		end
		if node.kind == AstKind.AssignmentVariable or node.kind == AstKind.VariableExpression then
			if node.scope:getVariableName(node.id) == "STRINGS" then
				data.scope:removeReferenceToHigherScope(node.scope, node.id)
				data.scope:addReferenceToHigherScope(scope, stringsVar)
				node.scope = scope
				node.id    = stringsVar
			end
		end
	end)

visitast(ast, nil, function(node, data)
    if node.kind == AstKind.StringExpression then
        data.scope:addReferenceToHigherScope(scope, stringsVar)
        data.scope:addReferenceToHigherScope(scope, decryptVar)
        local encrypted, seed = Encryptor.encrypt(node.value)
        return Ast.IndexExpression(
            Ast.VariableExpression(scope, stringsVar),
            Ast.FunctionCallExpression(Ast.VariableExpression(scope, decryptVar), {
                Ast.StringExpression(encrypted),
                Ast.NumberExpression(seed),
            })
        )
    end
end)

	table.insert(ast.body.statements, 1, doStat)
	table.insert(ast.body.statements, 1, Ast.LocalVariableDeclaration(scope, util.shuffle{ decryptVar, stringsVar }, {}))
	return ast
end

return EncryptStrings