-- namegenerators/sigil.lua
-- Sigil — by Zuka
--
-- Names built from alchemical symbols, letterlike symbols, and
-- mathematical operators — looks like arcane notation or a physics paper.
--
-- Visually: ℜℑℵℶ  ℧℃℉  ∂∆∇∞  ℓℏℝℂ
--
-- Why it's sick:
--   - Completely alien to anyone expecting code
--   - "Letterlike Symbols" block (U+2100–U+214F) contains things that
--     genuinely look like single characters but mean something arcane
--   - Mixed with math operators makes it look like formulas
--   - The aesthetic is genuinely unsettling — feels like cursed notation
--   - Still valid Lua 5.1 identifiers

local util = require("ZukaTech.util")

-- Letterlike symbols (U+2100–U+214F) — look like styled letters
local LETTERLIKE = {
    "\xE2\x84\x9C", -- ℜ BLACK-LETTER CAPITAL R
    "\xE2\x84\x91", -- ℑ BLACK-LETTER CAPITAL I
    "\xE2\x84\xB5", -- ℵ ALEF SYMBOL
    "\xE2\x84\xB6", -- ℶ BET SYMBOL
    "\xE2\x84\xB7", -- ℷ GIMEL SYMBOL
    "\xE2\x84\xB8", -- ℸ DALET SYMBOL
    "\xE2\x84\x82", -- ℂ DOUBLE-STRUCK CAPITAL C
    "\xE2\x84\x8D", -- ℍ DOUBLE-STRUCK CAPITAL H
    "\xE2\x84\x95", -- ℕ DOUBLE-STRUCK CAPITAL N
    "\xE2\x84\x99", -- ℙ DOUBLE-STRUCK CAPITAL P
    "\xE2\x84\x9A", -- ℚ DOUBLE-STRUCK CAPITAL Q
    "\xE2\x84\x9D", -- ℝ DOUBLE-STRUCK CAPITAL R
    "\xE2\x84\xA4", -- ℤ DOUBLE-STRUCK CAPITAL Z
    "\xE2\x84\x93", -- ℓ SCRIPT SMALL L
    "\xE2\x84\x8F", -- ℏ PLANCK CONSTANT OVER TWO PI
    "\xE2\x84\xA6", -- Ω OHM SIGN
    "\xE2\x84\xA7", -- ℧ INVERTED OHM SIGN
    "\xE2\x84\xA8", -- ℨ BLACK-LETTER CAPITAL Z
    "\xE2\x84\xAA", -- K DEGREE CELSIUS (looks like symbol)
    "\xE2\x84\xAB", -- Å DEGREE FAHRENHEIT
    "\xE2\x84\xAC", -- ℬ SCRIPT CAPITAL B
    "\xE2\x84\xAD", -- ℭ BLACK-LETTER CAPITAL C
    "\xE2\x84\xAF", -- ℯ SCRIPT SMALL E
    "\xE2\x84\xB0", -- ℰ SCRIPT CAPITAL E
    "\xE2\x84\xB1", -- ℱ SCRIPT CAPITAL F
    "\xE2\x84\xB3", -- ℳ SCRIPT CAPITAL M
    "\xE2\x84\xB4", -- ℴ SCRIPT SMALL O
    "\xE2\x84\x8B", -- ℋ SCRIPT CAPITAL H
    "\xE2\x84\x8C", -- ℌ BLACK-LETTER CAPITAL H
    "\xE2\x84\x90", -- ℐ SCRIPT CAPITAL I
}

-- Mathematical operators that look like symbols (U+2200–U+22FF)
local MATHOPS = {
    "\xE2\x88\x82", -- ∂ PARTIAL DIFFERENTIAL
    "\xE2\x88\x86", -- ∆ INCREMENT
    "\xE2\x88\x87", -- ∇ NABLA
    "\xE2\x88\x9E", -- ∞ INFINITY
    "\xE2\x88\x91", -- ∑ N-ARY SUMMATION
    "\xE2\x88\x8F", -- ∏ N-ARY PRODUCT
    "\xE2\x88\xAB", -- ∫ INTEGRAL
    "\xE2\x88\xAC", -- ∬ DOUBLE INTEGRAL
    "\xE2\x88\x9D", -- ∝ PROPORTIONAL TO
    "\xE2\x88\x80", -- ∀ FOR ALL
    "\xE2\x88\x83", -- ∃ THERE EXISTS
    "\xE2\x88\x84", -- ∄ THERE DOES NOT EXIST
    "\xE2\x88\x85", -- ∅ EMPTY SET
    "\xE2\x88\x88", -- ∈ ELEMENT OF
    "\xE2\x88\x8A", -- ∊ SMALL ELEMENT OF
    "\xE2\x88\x8B", -- ∋ CONTAINS AS MEMBER
    "\xE2\x88\x90", -- ∐ N-ARY COPRODUCT
    "\xE2\x88\x92", -- − MINUS SIGN (valid in ident)
    "\xE2\x88\xA7", -- ∧ LOGICAL AND
    "\xE2\x88\xA8", -- ∨ LOGICAL OR
    "\xE2\x88\xA9", -- ∩ INTERSECTION
    "\xE2\x88\xAA", -- ∪ UNION
}

-- Alchemical / misc technical symbols
local ALCH = {
    "\xE2\x8A\x95", -- ⊕ CIRCLED PLUS
    "\xE2\x8A\x96", -- ⊖ CIRCLED MINUS
    "\xE2\x8A\x97", -- ⊗ CIRCLED TIMES
    "\xE2\x8A\x98", -- ⊘ CIRCLED DIVISION
    "\xE2\x8A\x99", -- ⊙ CIRCLED DOT
    "\xE2\x8A\x9A", -- ⊚ CIRCLED RING
    "\xE2\x8A\x9B", -- ⊛ CIRCLED ASTERISK
    "\xE2\x8A\x9C", -- ⊜ CIRCLED EQUALS
    "\xE2\x8A\x9D", -- ⊝ CIRCLED DASH
    "\xE2\x8B\x85", -- ⋅ DOT OPERATOR
    "\xE2\x8B\x86", -- ⋆ STAR OPERATOR
    "\xE2\x8B\x87", -- ⋇ DIVISION TIMES
    "\xE2\x8B\x88", -- ⋈ BOWTIE
    "\xE2\x8B\x8A", -- ⋊ RIGHT NORMAL FACTOR SEMIDIRECT
    "\xE2\x8B\x8C", -- ⋌ REVERSED SEMIDIRECT PRODUCT
    "\xE2\x8B\x94", -- ⋔ PITCHFORK
}

local MIN_LEN = 2
local MAX_LEN = 6

-- Weighted family pool: letterlike chars dominate for readability
local FAMILIES  = { LETTERLIKE, LETTERLIKE, LETTERLIKE, MATHOPS, MATHOPS, ALCH }
local seed      = 0

local function prng(n)
    n = (n * 2246822519 + seed) % 0x100000000
    local result, bit, x, y = 0, 1, n, math.floor(n / 65536)
    for _ = 1, 32 do
        if x % 2 ~= y % 2 then result = result + bit end
        x = math.floor(x / 2); y = math.floor(y / 2); bit = bit * 2
    end
    return result
end

local function generateName(id, scope)
    local len  = MIN_LEN + (prng(id * 5) % (MAX_LEN - MIN_LEN + 1))
    local name = ""
    for i = 0, len - 1 do
        local fam = FAMILIES[(prng(id * 3 + i * 11) % #FAMILIES) + 1]
        local idx = (prng(id * 17 + i * 7) % #fam) + 1
        name = name .. fam[idx]
    end
    return "_" .. name
end

local function prepare(ast)
    seed = math.random(0, 0xFFFFFF)
    util.shuffle(LETTERLIKE)
    util.shuffle(MATHOPS)
    util.shuffle(ALCH)
end

return {
    generateName = generateName,
    prepare      = prepare,
}
