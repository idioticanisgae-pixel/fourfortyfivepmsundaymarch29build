-- ZukaTech Obfuscator — namegenerators/decesc.lua
-- Generates obfuscated identifier names and encoded string literals.
-- Fixed: generateName now returns valid identifiers; encoding is string-only.
local util = require("ZukaTech.util")
local seed   = 0
local offset = 0
local charsetHead = util.chararray("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_")
local charsetTail = util.chararray("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_0123456789")
local function hashVal(id)
    return (id * 2654435761 + seed * 0xBB38435) % 0xFFFFFFFF
end
local function baseEntropyName(id, len)
    local h = hashVal(id)
    len = len or (5 + (h % 7))
    local name = charsetHead[(h % #charsetHead) + 1]
    local v = h
    for _ = 1, len do
        v    = (v * 1664525 + 1013904223) % 0xFFFFFFFF
        name = name .. charsetTail[(v % #charsetTail) + 1]
    end
    return name
end
local function encodeString(str)
    local result = {}
    for i = 1, #str do
        result[i] = "\\" .. string.byte(str, i)
    end
    return table.concat(result)
end
local function encodeStr(str)
    return '"' .. encodeString(str) .. '"'
end
local function encodeNameAsString(id)
    return encodeString(baseEntropyName(id + offset))
end
local function generateName(id, scope)
    return baseEntropyName(id + offset)
end
local function prepare(ast)
    util.shuffle(charsetHead)
    util.shuffle(charsetTail)
    seed   = math.random(0, 0xFFFF)
    offset = math.random(0, 9999)
end
return {
    generateName     = generateName,
    encodeStr        = encodeStr,
    encodeString     = encodeString,
    encodeNameAsString = encodeNameAsString,
    prepare          = prepare,
}