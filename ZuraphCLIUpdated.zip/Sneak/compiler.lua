-- Callum's Stealth Architect CLI v2.0
-- Full Pipeline: Obfuscate -> luac51 -> Serialize -> VM Wrap -> Minify -> Compress
-- Usage: lua compiler.lua <input_file> [output_file]
--
-- Expected directory layout:
--   compiler.lua
--   input.lua
--   lua.exe  /  lua51.dll
--   luac51.exe  (or luac.exe)
--   Lua/
--     compress.lua
--     Minifier/  (init, llex, lparser, optlex, optparser, utils)
--   modules/Compiler/
--     bit.lua  Serializer.lua  Deserializer.lua  Opcode.lua  VMStrings.lua

local input_path  = arg[1]
local output_path = arg[2] or "output.lua"

if not input_path then
    print("Usage: lua compiler.lua <input.lua> [output.lua]")
    os.exit(1)
end

-- ============================================================
-- CONFIGURATION
-- ============================================================

local TARGET_GLOBALS = {
    "getrawmetatable", "setreadonly", "hookmetamethod", "checkcaller",
    "getgenv", "getrenv", "getreg", "getgc", "hookfunction", "newcclosure",
    "getnamecallmethod", "game", "workspace", "script",
    "Instance", "Vector3", "CFrame", "Players", "RunService", "task",
    "FireServer", "InvokeServer", "WalkSpeed", "JumpPower"
}

-- Safe XOR key: avoid NUL (0x00) and DEL (0x7F)
math.randomseed(os.time())
local KEY = math.random(0x11, 0x7E)

-- Charset for VM bytecode encoding (alphanumeric, no Lua/shell specials)
local CHARSET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

-- luac binaries to probe, in priority order
-- luac.exe is listed first because that is what ships in the beta directory
local LUAC_CANDIDATES = { "luac.exe", "luac51.exe", "luac51", "luac" }

-- ============================================================
-- PURE LUA 5.1 BITWISE  (compiler-side, no bit32)
-- ============================================================

local function bxor(a, b)
    local r, m = 0, 1
    while a > 0 or b > 0 do
        local aa, bb = a % 2, b % 2
        if aa ~= bb then r = r + m end
        a, b, m = math.floor(a / 2), math.floor(b / 2), m * 2
    end
    return r
end

-- ============================================================
-- UTILITIES
-- ============================================================

local function encrypt_string(str)
    local bytes = {}
    for i = 1, #str do
        bytes[i] = tostring(bxor(string.byte(str, i), KEY))
    end
    return "{" .. table.concat(bytes, ",") .. "}"
end

local function encrypt_chars(str)
    local parts = {}
    for i = 1, #str do
        parts[i] = tostring(bxor(string.byte(str, i), KEY))
    end
    return table.concat(parts, ",")
end

-- Collision-free obfuscated name generator
local _hex_used = {}
local function generate_hex(len)
    local chars = "0123456789abcdef"
    local name
    repeat
        name = "_0x"
        for _ = 1, len do
            local i = math.random(1, #chars)
            name = name .. chars:sub(i, i)
        end
        name = name .. string.format("%03x", math.random(0, 0xFFF))
    until not _hex_used[name]
    _hex_used[name] = true
    return name
end

local function read_file(path, mode)
    local f = io.open(path, mode or "rb")
    if not f then return nil end
    local d = f:read("*all"); f:close(); return d
end

local function write_file(path, data)
    local f = io.open(path, "wb")
    if not f then return false end
    f:write(data); f:close(); return true
end

-- ============================================================
-- MODULE PATHS
-- ============================================================

-- Paths match the actual beta directory layout:
--   Lua/modules/  -> Deserializer, Serializer, Opcode, VMStrings, bit
--   Lua/Minifier/ -> init (required as "minify"), llex, lparser, etc.
package.path = package.path
    .. ";./Lua/?.lua"
    .. ";./Lua/Minifier/?.lua"
    .. ";./Lua/modules/?.lua"

-- ============================================================
-- READ INPUT
-- ============================================================

local source = read_file(input_path, "r")
if not source then
    print("[-] Cannot open input file: " .. input_path)
    os.exit(1)
end

print("")
print("+==============================================+")
print("|    Stealth Architect v2.0  [Full Pipeline]   |")
print("+==============================================+")
print("[+] Input  : " .. input_path)
print("[+] Output : " .. output_path)
print("[+] XOR Key: 0x" .. string.format("%X", KEY))
print("")

-- ============================================================
-- PHASE 1 — Hide string literals before global masking
-- ============================================================

print("[1/7] Masking string literals...")

local string_placeholders = {}
local ph_counter = 0

local function placeholder_for(s)
    ph_counter = ph_counter + 1
    local ph = "\1PH" .. ph_counter .. "\1"          -- \1 is safe; never appears in Lua source
    string_placeholders[ph] = "_S(" .. encrypt_string(s) .. ")"
    return ph
end

source = source:gsub('"(.-)"', function(s) return placeholder_for(s) end)
source = source:gsub("'(.-)'",  function(s) return placeholder_for(s) end)

print("    " .. ph_counter .. " string(s) hidden")

-- ============================================================
-- PHASE 2 — Mask executor / Roblox globals via XOR lookup
-- ============================================================

print("[2/7] Masking globals...")

local globals_masked = 0
for _, word in ipairs(TARGET_GLOBALS) do
    local new_src, n = source:gsub(
        "%f[%w_](" .. word .. ")%f[^%w_]",
        function() return "_R(" .. encrypt_string(word) .. ")" end
    )
    source        = new_src
    globals_masked = globals_masked + n
end

print("    " .. globals_masked .. " reference(s) masked")

-- ============================================================
-- PHASE 3 — Scramble local variable names
-- ============================================================

print("[3/7] Scrambling locals...")

local varMap   = {}
local reserved = {
    -- Lua 5.1 keywords
    ["and"]=true,["break"]=true,["do"]=true,["else"]=true,["elseif"]=true,
    ["end"]=true,["false"]=true,["for"]=true,["function"]=true,["if"]=true,
    ["in"]=true,["local"]=true,["nil"]=true,["not"]=true,["or"]=true,
    ["repeat"]=true,["return"]=true,["then"]=true,["true"]=true,
    ["until"]=true,["while"]=true,
    -- Internal runtime names
    ["_S"]=true,["_R"]=true,["_E"]=true,["_K"]=true,
    ["_bxor"]=true,["_L"]=true,["_T"]=true,
}

source = source:gsub("local%s+([%a_][%w_]*)%s*=", function(v)
    if not reserved[v] and not varMap[v] then
        varMap[v] = generate_hex(4)
    end
    return "local " .. (varMap[v] or v) .. " ="
end)

-- Longest-first to prevent partial-name collisions
local sorted_vars = {}
for raw in pairs(varMap) do sorted_vars[#sorted_vars + 1] = raw end
table.sort(sorted_vars, function(a, b) return #a > #b end)

for _, raw in ipairs(sorted_vars) do
    source = source:gsub("%f[%w_]" .. raw .. "%f[^%w_]", varMap[raw])
end

print("    " .. #sorted_vars .. " variable(s) renamed")

-- ============================================================
-- PHASE 3b — Restore string placeholders
-- ============================================================

for ph, replacement in pairs(string_placeholders) do
    -- \1 is literal; escape it for gsub
    local pattern = ph:gsub("\1", "\1")
    source = source:gsub(pattern, replacement, 1)
end

-- ============================================================
-- PHASE 3c — Wrap in XOR runtime shell
-- ============================================================

local task_enc = encrypt_chars("task")

local obfuscated_source = string.format([=[
return (function(...)
    local _E=getfenv and getfenv() or _G
    local _K=%d
    local function _bxor(a,b)
        local r,m=0,1
        while a>0 or b>0 do
            local aa,bb=a%%2,b%%2
            if aa~=bb then r=r+m end
            a,b,m=math.floor(a/2),math.floor(b/2),m*2
        end
        return r
    end
    local function _S(t)
        local s={}
        for i=1,#t do s[i]=string.char(_bxor(t[i],_K)) end
        return table.concat(s)
    end
    local function _R(q) return _E[_S(q)] end
    do
        local _L=function(...)
            %s
        end
        local _T=_R({%s})
        _T.spawn(_L,...)
        _E,_K,_bxor,_S,_R,_L,_T=nil,nil,nil,nil,nil,nil,nil
    end
end)(...)
]=], KEY, source, task_enc)

-- ============================================================
-- PHASE 4 — Compile to bytecode via luac51
-- ============================================================

print("[4/7] Compiling to Lua 5.1 bytecode...")

local luac_bin = nil
for _, candidate in ipairs(LUAC_CANDIDATES) do
    local probe = io.popen(candidate .. " -v 2>&1")
    if probe then
        local out = probe:read("*all"); probe:close()
        if out and out:find("Lua 5%.1") then
            luac_bin = candidate; break
        end
    end
end

local have_bytecode = false

if not luac_bin then
    print("    WARNING: luac51 not found — skipping bytecode + VM phases.")
    print("    Place luac51.exe next to compiler.lua and rerun for full protection.")
else
    print("    Using: " .. luac_bin)

    local tmp_src = os.tmpname() .. ".lua"
    local tmp_bc  = os.tmpname() .. ".luac"

    write_file(tmp_src, obfuscated_source)

    local cmd  = string.format('%s -s -o "%s" "%s" 2>&1', luac_bin, tmp_bc, tmp_src)
    local proc = io.popen(cmd)
    local err  = proc:read("*all"); proc:close()
    local bc   = read_file(tmp_bc)

    os.remove(tmp_src)
    os.remove(tmp_bc)

    if not bc or #bc == 0 then
        print("    luac error: " .. (err or "unknown"))
        print("    Falling back to source-only path.")
    else
        print("    Bytecode: " .. #bc .. " bytes")
        have_bytecode = true

        -- ============================================================
        -- PHASE 5 — Serialize bytecode -> VM wrapper
        -- ============================================================

        print("[5/7] Building VM wrapper...")

        local ok_des, Deserialize    = pcall(require, "Deserializer")
        local ok_ser, Serialize      = pcall(require, "Serializer")
        local ok_opc, GetOpcodeCode  = pcall(require, "Opcode")
        local ok_vm,  VMStrings      = pcall(require, "VMStrings")

        if not (ok_des and ok_ser and ok_opc and ok_vm) then
            print("    WARNING: VM module(s) missing — using raw bytecode table.")
            if not ok_des then print("    Deserializer: " .. tostring(Deserialize)) end
            if not ok_ser then print("    Serializer  : " .. tostring(Serialize))   end
            if not ok_opc then print("    Opcode      : " .. tostring(GetOpcodeCode)) end
            if not ok_vm  then print("    VMStrings   : " .. tostring(VMStrings))   end

            -- Fallback: embed raw bytes, execute via loadstring
            local bc_tbl = {}
            for i = 1, #bc do bc_tbl[i] = string.byte(bc, i) end
            obfuscated_source = string.format(
                "local _t={%s}\nlocal _s={}\nfor i=1,#_t do _s[i]=string.char(_t[i]) end\nloadstring(table.concat(_s))()\n",
                table.concat(bc_tbl, ",")
            )
        else
            -- Deserialize luac chunk
            local chunk = Deserialize(bc)

            -- Re-serialize into our custom binary format
            local serialized = Serialize(chunk)

            -- Base-N encode serialized bytes, separated by "_"
            local base  = #CHARSET
            local parts = {}
            for i = 1, #serialized do
                local bv = string.byte(serialized, i)
                if bv == 0 then
                    parts[#parts + 1] = CHARSET:sub(1, 1)
                else
                    local digits = {}
                    local n = bv
                    while n > 0 do
                        local rem = n % base
                        table.insert(digits, 1, CHARSET:sub(rem + 1, rem + 1))
                        n = math.floor(n / base)
                    end
                    parts[#parts + 1] = table.concat(digits)
                end
            end
            local encoded_bc = table.concat(parts, "_")

            -- Build opcode dispatch from only the opcodes actually used
            local cases = {}
            for op_num in pairs(_G.UsedOps or {}) do
                local body = GetOpcodeCode(op_num)
                if body then
                    cases[#cases + 1] = { op = op_num, body = body }
                end
            end
            table.sort(cases, function(a, b) return a.op < b.op end)

            local dispatch_parts = {}
            for idx, entry in ipairs(cases) do
                local kw = (idx == 1) and "if" or "elseif"
                dispatch_parts[#dispatch_parts + 1] = string.format(
                    "        %s S==%d then\n%s", kw, entry.op, entry.body
                )
            end
            dispatch_parts[#dispatch_parts + 1] = "        end"
            local dispatch = table.concat(dispatch_parts, "\n")

            -- Resolve _ / __ placeholders in VMStrings (0 and 1)
            local function resolve(s)
                return s
                    :gsub("%f[%w_]_%f[^%w_]",  "0")
                    :gsub("%f[%w_]__%f[^%w_]", "1")
            end

            local vm_vars   = resolve(VMStrings.Variables)
            local vm_deser  = resolve(VMStrings.Deserializer)
            local vm_wrap1  = resolve(VMStrings.Wrapper_1)
                                  :gsub("while alpha do", "while true do")
            local vm_wrap2  = resolve(VMStrings.Wrapper_2)

            obfuscated_source = string.format(
[=[
;(function(...)
%s

%s

%s
%s
%s

    local _charset=%q
    local _bc=%q
    local _chunk=BcToState(_bc,_charset)
    local _env=getfenv and getfenv() or _G
    local _entry=WrapState(_chunk,_env,nil)
    _entry(...)
end)(...)
]=],
                vm_vars, vm_deser,
                vm_wrap1, dispatch, vm_wrap2,
                CHARSET, encoded_bc
            )

            print("    VM assembled — " .. #cases .. " opcode handler(s)")
        end
    end
end

-- ============================================================
-- PHASE 6 — Minify
-- ============================================================

print("[6/7] Minifying...")

local ok_min, Minify = pcall(require, "minify")
if ok_min then
    local ok_opt, result = pcall(Minify.optimize, Minify.MAXIMUM_OPTS, obfuscated_source)
    if ok_opt and result then
        print("    " .. #obfuscated_source .. " -> " .. #result .. " bytes")
        obfuscated_source = result
    else
        print("    Optimize pass failed: " .. tostring(result))
    end
else
    print("    Minifier not found (Lua/Minifier/). Skipping.")
end

-- ============================================================
-- PHASE 7 — LZW Compress + self-extracting wrapper
-- ============================================================

print("[7/7] Compressing...")

local function lzw_compress(input)
    if type(input) ~= "string" then return "u" .. input end
    local len = #input
    if len <= 1 then return "u" .. input end

    local char, sub, tconcat = string.char, string.sub, table.concat
    local bd = {}
    for i = 0, 255 do bd[char(i)] = char(i, 0) end

    local function dadd(str, dict, a, b)
        if a >= 256 then
            a, b = 0, b + 1
            if b >= 256 then dict = {} b = 1 end
        end
        dict[str] = char(a, b)
        return dict, a + 1, b
    end

    local dict = {}
    local a, b = 0, 1
    local res  = {"c"}
    local n, rlen = 2, 1
    local word = ""

    for i = 1, len do
        local c  = sub(input, i, i)
        local wc = word .. c
        if not (bd[wc] or dict[wc]) then
            local w = bd[word] or dict[word]
            if not w then return "u" .. input end
            res[n] = w
            rlen   = rlen + #w
            n      = n + 1
            if len <= rlen then return "u" .. input end
            dict, a, b = dadd(wc, dict, a, b)
            word = c
        else
            word = wc
        end
    end
    local last = bd[word] or dict[word]
    if not last then return "u" .. input end
    res[n] = last
    rlen   = rlen + #res[n]
    if len <= rlen then return "u" .. input end
    return tconcat(res)
end

local compressed = lzw_compress(obfuscated_source)

-- Encode as decimal-escaped byte string
local esc = {}
for i = 1, #compressed do
    esc[i] = "\\" .. string.byte(compressed, i)
end
local comp_str = table.concat(esc)

local ratio = string.format("%.1f", (#compressed / #obfuscated_source) * 100)
print("    " .. #obfuscated_source .. " -> " .. #compressed .. " bytes (" .. ratio .. "%)")

-- ============================================================
-- ASSEMBLE FINAL OUTPUT
-- Fully self-contained: decompress -> loadstring -> run
-- ============================================================

local final_output = [=[
;(function(...)
    local _src="]=] .. comp_str .. [=["
    local function _decomp(inp)
        local char=string.char local sub=string.sub local tc=table.concat
        local bd={}
        for i=0,255 do bd[char(i,0)]=char(i) end
        local function add(s,d,a,b)
            if a>=256 then a,b=0,b+1 if b>=256 then d={} b=1 end end
            d[char(a,b)]=s return d,a+1,b
        end
        local ctrl=sub(inp,1,1) inp=sub(inp,2)
        if ctrl=="u" then return inp end
        local len=#inp local d={} local a,b=0,1
        local r={} local n=1
        local last=sub(inp,1,2)
        r[n]=bd[last] n=n+1
        for i=3,len,2 do
            local code=sub(inp,i,i+1)
            local ls=bd[last] or d[last]
            local ta=bd[code] or d[code]
            if ta then
                r[n]=ta n=n+1
                d,a,b=add(ls..sub(ta,1,1),d,a,b)
            else
                local tmp=ls..sub(ls,1,1)
                r[n]=tmp n=n+1
                d,a,b=add(tmp,d,a,b)
            end
            last=code
        end
        return tc(r)
    end
    local _f=loadstring(_decomp(_src))
    if _f then
        if setfenv then setfenv(_f,getfenv()) end
        return _f(...)
    end
end)(...)
]=]

-- ============================================================
-- WRITE OUTPUT
-- ============================================================

if not write_file(output_path, final_output) then
    print("[-] Error writing output: " .. output_path)
    os.exit(1)
end

print("")

print("Ugh why can't this work")                         

print("[+] Output   : " .. output_path)
print("[+] Final sz : " .. #final_output .. " bytes")
print("[+] Strings  : " .. ph_counter    .. " encrypted")
print("[+] Globals  : " .. globals_masked .. " masked")
print("[+] Locals   : " .. #sorted_vars  .. " scrambled")
print("[+] VM       : " .. (have_bytecode and "YES" or "NO (luac51 not found)"))
print("[+] Key      : 0x" .. string.format("%X", KEY))
print("")
